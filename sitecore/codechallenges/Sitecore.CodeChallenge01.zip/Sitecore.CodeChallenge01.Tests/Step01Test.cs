﻿using Sitecore.CodeChallenge01.Fields;
using Sitecore.CodeChallenge01.Secret;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI;
using Xunit;

namespace Sitecore.CodeChallenge01.Tests
{
    public class Step01Test
    {
        private class QRCodeFieldImpl : QRCodeField, Step01Secret.IRealValue
        {
            public string RealValue
            {
                set
                {
                    this.SetViewStateString("Value", value);
                }
            }
        }

        [Fact]
        public void Test0101()
        {
            Step01Secret.Test0101();
        }

        [Fact]
        public void Test0102()
        {
            Step01Secret.Test0102(new QRCodeFieldImpl());
        }
    }
}
