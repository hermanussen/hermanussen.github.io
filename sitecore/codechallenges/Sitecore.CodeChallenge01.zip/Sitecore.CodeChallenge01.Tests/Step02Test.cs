﻿using Sitecore.CodeChallenge01.Secret;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Sitecore.CodeChallenge01.Tests
{
    public class Step02Test
    {
        [Fact]
        public void Test0201()
        {
            Step02Secret.Test0201();
        }
    }
}
