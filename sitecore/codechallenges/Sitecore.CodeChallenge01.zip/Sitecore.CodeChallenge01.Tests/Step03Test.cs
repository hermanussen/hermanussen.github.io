﻿using Sitecore.CodeChallenge01.Pipelines.RenderField;
using Sitecore.CodeChallenge01.Secret;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Sitecore.CodeChallenge01.Tests
{
    public class Step03Test
    {

        [Fact]
        public void Test0301()
        {
            Step03Secret.Test0301();
        }

        [Fact]
        public void Test0302()
        {
            Step03Secret.Test0302(GetQRFieldValue.RenderImageHtml);
        }
    }
}
