﻿using Sitecore.Web.UI.HtmlControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI;

namespace Sitecore.CodeChallenge01.Fields
{
    public class QRCodeField : Edit
    {
        // Implementation needed
    }
}
