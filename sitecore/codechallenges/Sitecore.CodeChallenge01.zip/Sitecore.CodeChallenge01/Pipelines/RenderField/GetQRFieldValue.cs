﻿using Sitecore.Diagnostics;
using Sitecore.Pipelines.RenderField;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Sitecore.CodeChallenge01.Pipelines.RenderField
{
    public class GetQRFieldValue
    {
        public void Process(RenderFieldArgs args)
        {
            Assert.ArgumentNotNull((object)args, "args");
            if (args.FieldTypeKey != "qr code")
            {
                return;
            }
            args.Result.FirstPart = RenderImageHtml(args.Result.FirstPart);
        }

        public static string RenderImageHtml(string text)
        {
            // Implementation needed
            return null;
        }
    }
}
