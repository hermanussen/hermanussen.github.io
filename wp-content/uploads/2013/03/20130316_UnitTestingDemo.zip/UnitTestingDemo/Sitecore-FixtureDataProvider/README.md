Sitecore-FixtureDataProvider
============================

An in-memory data provider for Sitecore that can read fixtures on startup and keeps track of changes in Sitecore as long as the program runs

Check my blog for more info: http://hermanussen.eu/sitecore/wordpress/2012/06/sitecore-unit-testing-with-test-fixtures/

Robin Hermanussen