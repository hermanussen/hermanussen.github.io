﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Sitecore.Configuration;

namespace FixtureDataProvider.Mocking
{
    public class EmptyDataStore : ClientDataStore
    {
        public EmptyDataStore() : base(TimeSpan.MinValue)
        {
        }

        protected override void CompactData()
        {
        }

        protected override string LoadData(string key)
        {
            return null;
        }

        protected override void RemoveData(string key)
        {
            
        }

        protected override void SaveData(string key, string data)
        {
            
        }
    }
}
