﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Linq;
using CompiledDomainModel.Core;
using Sitecore.Data;
using Sitecore.Data.Fields;
using Sitecore.Data.Items;
using Sitecore.Links;
using UnitTestingDemo.Website.Domain;
using UnitTestingDemo.Website.Domain.DomainModel;
using UnitTestingDemo.Website.Domain.FixedPaths.Content.UnitTestingDemo.ReusableContent;

namespace UnitTestingDemo.Website.Util
{
    public static class RecipeImportUtil
    {
        public static Recipe ImportRecipe(IItemWrapper startItem, XElement recipeElement)
        {
            string title = recipeElement.Element("head").Element("title").Value;
            string recipeItemName = ItemUtil.ProposeValidItemName(title);

            if (startItem.Item.Axes.GetChild(recipeItemName) != null)
            {
                throw new RecipeImportException(string.Format("Recipe {0} already exists", recipeItemName));
            }

            Recipe importedRecipe = Create<Recipe>(startItem, title);
            using (new EditContext(importedRecipe.Item))
            {
                importedRecipe.Title = title;
                importedRecipe.TextContent =
                    new XElement("ol", new XAttribute("class", "unstyled"),
                                 recipeElement.Element("directions")
                                       .Elements("step")
                                       .Select(step => new XElement("li", step.Value))).ToString();

                MultilistField categoriesField = FieldTypeManager.GetField(
                        importedRecipe.Item.Fields[Recipe.FIELD_CATEGORIES]) as MultilistField;
                foreach (XElement cat in recipeElement.Element("head").Element("categories").Elements("cat"))
                {
                    RecipeCategory category = EnsureRecipeCategory(cat.Value);
                    if (categoriesField.TargetIDs.Contains(category.Item.ID))
                    {
                        continue;
                    }
                    using (new EditContext(category.Item))
                    {
                        categoriesField.Add(category.Item.ID.ToString(), false);
                    }
                }
            }
            
            foreach (XElement ing in recipeElement.Element("ingredients").Descendants("ing"))
            {
                Ingredient ingredient = EnsureIngredient(ing.Element("item").Value);
                ImportIngredientUse(importedRecipe, ing.Element("amt"), ingredient);
            }

            return importedRecipe;
        }

        public static RecipeCategory EnsureRecipeCategory(string categoryName)
        {
            IEnumerable<RecipeCategory> recipeCategories = RecipeCategoriesFixed.ItemWrapper.GetChildren<RecipeCategory>() ?? new RecipeCategory[0];
            RecipeCategory existing = recipeCategories.FirstOrDefault(cat => categoryName.Equals(cat.CategoryName));
            if (existing != null)
            {
                return existing;
            }
            existing = Create<RecipeCategory>(RecipeCategoriesFixed.ItemWrapper, categoryName);
            using (new EditContext(existing.Item))
            {
                existing.CategoryName = categoryName;
            }
            return existing;
        }

        public static Ingredient EnsureIngredient(string ingredientName)
        {
            IEnumerable<Ingredient> ingredients = IngredientsFixed.ItemWrapper.GetChildren<Ingredient>() ?? new Ingredient[0];
            Ingredient existing = ingredients.FirstOrDefault(ing => ingredientName.Equals(ing.Name));
            if (existing != null)
            {
                return existing;
            }
            existing = Create<Ingredient>(IngredientsFixed.ItemWrapper, ingredientName);
            using (new EditContext(existing.Item))
            {
                existing.Name = ingredientName;
            }
            return existing;
        }

        public static IngredientUse ImportIngredientUse(Recipe recipe, XElement ingredientUseElement,
                                                        Ingredient ingredient)
        {
            IngredientUse ingredientUse = Create<IngredientUse>(recipe, ingredient.Name);
            using (new EditContext(ingredientUse.Item))
            {
                InternalLinkField ingredientLink =
                    FieldTypeManager.GetField(ingredientUse.Item.Fields[IngredientUse.FIELD_INGREDIENT]) as InternalLinkField;
                ingredientLink.UpdateLink(new ItemLink(ingredientUse.Item, ingredientLink.InnerField.ID, ingredient.Item, ingredient.Item.Paths.FullPath));
                
                ingredientUse.Quantity = ingredientUseElement.Element("qty").Value;
                ingredientUse.Unit = ingredientUseElement.Element("unit").Value;
            }
            return ingredientUse;
        }

        private static T Create<T>(IItemWrapperCore parent, string name) where T : ItemWrapper
        {
            TemplateID templateId = new TemplateID((ID) typeof (T).GetField("TEMPLATE_ID").GetValue(null));
            ItemWrapper created = ItemWrapper.CreateTypedWrapper(parent.Item.Add(ItemUtil.ProposeValidItemName(name), templateId));
            return (T) created;
        }
    }

    public class RecipeImportException : Exception
    {
        public RecipeImportException(string message)
            : base(message)
        {
        }
    }
}