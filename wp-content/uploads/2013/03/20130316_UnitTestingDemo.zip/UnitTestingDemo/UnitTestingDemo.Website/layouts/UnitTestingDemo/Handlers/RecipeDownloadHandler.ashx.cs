﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Xml.Linq;
using Sitecore.Configuration;
using Sitecore.Data;
using Sitecore.Data.Items;
using Sitecore.Web;
using UnitTestingDemo.Website.Domain;
using UnitTestingDemo.Website.Domain.DomainModel;

namespace UnitTestingDemo.Website.layouts.UnitTestingDemo.Handlers
{
    public class RecipeDownloadHandler : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            if(ShortID.IsShortID(WebUtil.GetQueryString("id")))
            {
                Item item = Sitecore.Context.Database.GetItem(ShortID.Parse(WebUtil.GetQueryString("id")).ToID());
                if (item != null)
                {
                    Recipe recipe = ItemWrapper.CreateTypedWrapper(item) as Recipe;
                    if (recipe != null)
                    {
                        context.Response.ClearContent();
                        context.Response.AddHeader("Content-Disposition",
                            string.Format("attachment; filename={0}.xml", recipe.Title));
                        context.Response.ContentType = "application/xml";
                        context.Response.Write(GetRecipeML(recipe));
                        return;
                    }
                }
            }
            context.Response.StatusCode = 404;
            WebUtil.Redirect(Settings.ItemNotFoundUrl);
        }

        /// <summary>
        /// Exports a recipe to RecipeML XML format.
        /// </summary>
        /// <param name="recipe">The recipe item from Sitecore, wrapped in the CDM generated wrapper</param>
        /// <returns>A valid RecipeML document</returns>
        public static XDocument GetRecipeML(Recipe recipe)
        {
            if (recipe == null)
            {
                return null;
            }

            XElement head = new XElement("head", new XElement("title", recipe.Title));
            if (recipe.GetCategories<RecipeCategory>() != null)
            {
                head.Add(new XElement("categories", recipe.GetCategories<RecipeCategory>()
                    .Select(cat => new XElement("cat", cat.CategoryName))));
            }

            XElement ingredients = new XElement("ingredients");
            foreach (IngredientUse ingredientUse in (recipe.GetChildren<IngredientUse>() ?? new IngredientUse[0]))
            {
                ingredients.Add(new XElement("ing",
                    new XElement("amt",
                        new XElement("qty", ingredientUse.Quantity),
                        new XElement("unit", ingredientUse.Unit)),
                    new XElement("item", ingredientUse.GetIngredient<Ingredient>().Name)));
            }

            XElement directions = new XElement("directions");
            directions.Add(new XElement("step", Regex.Replace(recipe.TextContent, "<.*?>", string.Empty)));

            return new XDocument(
                new XElement("recipeml", new XAttribute("version", "0.5"),
                    new XElement("recipe", 
                        head,
                        ingredients,
                        directions)));
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}