﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Sitecore.Data.Items;

namespace UnitTestingDemo.Website.layouts.sublayouts.UnitTestingDemo
{
    public partial class NavBarSublayout : System.Web.UI.UserControl
    {
        private Item homeItem;
        public Item HomeItem
        {
            get
            {
                return homeItem ?? (homeItem = Sitecore.Context.Database.GetItem(Sitecore.Context.Site.StartPath));
            }
        }
    }
}