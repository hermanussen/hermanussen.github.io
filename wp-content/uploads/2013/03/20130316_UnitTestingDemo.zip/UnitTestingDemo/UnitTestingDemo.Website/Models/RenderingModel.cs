﻿using Sitecore.Mvc.Presentation;
using UnitTestingDemo.Website.Domain;

namespace UnitTestingDemo.Website.Models
{
    /// <summary>
    /// Use this interface as a model for a Razor view if you want to use a CDM wrapper from the view.
    /// </summary>
    /// <typeparam name="T">The type of the wrapper that the model needs to support</typeparam>
    public interface IRenderingModel<out T> : IRenderingModel where T : ItemWrapper
    {
        T Item { get; }
        ItemWrapper PageItem { get; }
        Rendering Rendering { get; }
    }

    /// <summary>
    /// Default CDM rendering model implementation as used by the CreateTypedRenderingModel pipeline processor.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class RenderingModel<T> : IRenderingModel<T> where T : ItemWrapper
    {
        private Rendering rendering;
        private T item;
        private ItemWrapper pageItem;

        public void Initialize(Rendering rendering)
        {
            this.rendering = rendering;
        }

        /// <summary>
        /// Returns the CDM wrapped item.
        /// This can be the context item, or the item based on the datasource of the rendering.
        /// </summary>
        public virtual T Item
        {
            get
            {
                if (item == null)
                {
                    ItemWrapper typedWrapper = ItemWrapper.CreateTypedWrapper(rendering.Item);
                    if (typedWrapper is T)
                    {
                        item = (T) typedWrapper;
                    }
                }
                return item;
            }
        }

        /// <summary>
        /// The wrapped item for the entire page (from the page context).
        /// </summary>
        public virtual ItemWrapper PageItem
        {
            get
            {
                return pageItem ?? (pageItem = ItemWrapper.CreateTypedWrapper(PageContext.Current.Item));
            }
        }

        public virtual Rendering Rendering
        {
            get { return rendering; }
        }
    }
}