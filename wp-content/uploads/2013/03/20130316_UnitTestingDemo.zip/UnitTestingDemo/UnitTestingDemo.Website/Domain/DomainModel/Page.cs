﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sitecore.Links;

namespace UnitTestingDemo.Website.Domain.DomainModel
{
    public partial class Page
    {
        public string PageUrl
        {
            get { return LinkManager.GetItemUrl(Item); }
        }
    }
}