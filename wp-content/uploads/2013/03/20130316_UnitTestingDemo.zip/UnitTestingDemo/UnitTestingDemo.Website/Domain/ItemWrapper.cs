﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sitecore.Data;

namespace UnitTestingDemo.Website.Domain
{
    public partial class ItemWrapper
    {
        public static Type GetTypeForTemplateId(ID templateId)
        {
            return TypeMappings.ContainsKey(templateId)
                       ? TypeMappings[templateId]
                       : null;
        }
    }
}