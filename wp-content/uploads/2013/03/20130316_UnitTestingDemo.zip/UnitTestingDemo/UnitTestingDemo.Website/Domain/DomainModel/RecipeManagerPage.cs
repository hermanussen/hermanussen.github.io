﻿using System.Collections.Generic;
using System.Linq;

namespace UnitTestingDemo.Website.Domain.DomainModel
{
    public partial class RecipeManagerPage
    {
        private ICollection<Recipe> recipes;
        public ICollection<Recipe> Recipes
        {
            get
            {
                return recipes ?? (recipes = (GetChildren<Recipe>() ?? new Recipe[0]).ToList());
            }
        }
    }
}