﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Xml.Linq;
using Sitecore.Data;
using Sitecore.Data.Items;
using Sitecore.Diagnostics;
using Sitecore.Mvc.Presentation;
using Sitecore.SecurityModel;
using Sitecore.Zip;
using UnitTestingDemo.Website.Domain;
using UnitTestingDemo.Website.Domain.DomainModel;
using UnitTestingDemo.Website.Models;
using UnitTestingDemo.Website.Util;

namespace UnitTestingDemo.Website.Controllers
{
    public class RecipeManagerController : Controller
    {
        private const string ViewPath = "~/Views/UnitTestingDemo/RecipeManager/RecipeManagerRendering.cshtml";
        
        public ActionResult Index()
        {
            return View(ViewPath, GetModel<RecipeManagerPage>());
        }

        [HttpPost]
        public ActionResult Index(HttpPostedFileBase file)
        {
            IRenderingModel<RecipeManagerPage> model = GetModel<RecipeManagerPage>();

            string message;
            int recipeCount;
            using (new SecurityDisabler())
            {
                if ("application/x-zip-compressed".Equals(file.ContentType, StringComparison.InvariantCultureIgnoreCase))
                {
                    // Handle zip file with recipes
                    recipeCount = 0;
                    bool success = true;
                    using (var zipReader = new ZipReader(file.InputStream))
                    {
                        foreach (ZipEntry recipeFile in zipReader.Entries.Where(entry => entry.Name.EndsWith(".xml", StringComparison.InvariantCultureIgnoreCase)))
                        {
                            int recipesInZipCount = 0;
                            string messageInFile;
                            success = success && Upload(model.Item, recipeFile.Name, recipeFile.GetStream(), out messageInFile, out recipesInZipCount);
                            recipeCount += recipesInZipCount;
                        }
                    }
                    message = string.Format(success
                        ? "Successfully imported {0} recipes from zip file."
                        : "Successfully imported {0} recipes from zip file. But not everything in the zip file was successfully imported.",
                        recipeCount);
                    ViewBag.UploadStatusSuccess = success;
                }
                else
                {
                    // Handle normal XML upload
                    ViewBag.UploadStatusSuccess = Upload(model.Item, file.FileName, file.InputStream, out message, out recipeCount);
                }
            }
            ViewBag.UploadStatusMessage = message;
            
            return View(ViewPath, model);
        }

        private bool Upload(IItemWrapper startItem, string fileName, Stream inputStream, out string message, out int recipeCount)
        {
            recipeCount = 0;
            if (string.IsNullOrWhiteSpace(fileName))
            {
                message = "The filename was empty. Please provide a valid file.";
                return false;
            }
            XDocument recipeMl;
            try
            {
                recipeMl = XDocument.Load(inputStream);
            }
            catch (Exception)
            {
                message = "The file could not be parsed as XML. Please provide a valid file.";
                return false;
            }
            if (recipeMl.Root == null)
            {
                message = "Root element for the recipeML file could not be found. Please provide a valid file.";
                return false;
            }
            foreach (XElement recipe in recipeMl.Root.Elements("recipe"))
            {
                try
                {
                    Recipe importedRecipe = RecipeImportUtil.ImportRecipe(startItem, recipe);
                    Log.Info(string.Format("Imported recipe '{0}'", importedRecipe.Title), this);
                    recipeCount++;
                }
                catch (RecipeImportException e)
                {
                    Log.Error(e.Message, e, this);
                    message = string.Format("Import failed: {0}", e.Message);
                    return false;
                }
            }
            message = string.Format("Imported {0} recipe(s) into Sitecore", recipeCount);
            return true;
        }

        private static IRenderingModel<T> GetModel<T>() where T : ItemWrapper
        {
            IRenderingModel<T> model = new RenderingModel<T>();
            model.Initialize(new Rendering() { Item = Sitecore.Context.Item });
            return model;
        }

    }
}
