﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Sitecore.Data;
using Sitecore.Data.Items;
using UnitTestingDemo.Website.Domain;
using UnitTestingDemo.Website.Domain.DomainModel;
using UnitTestingDemo.Website.Tests.Util;
using UnitTestingDemo.Website.layouts.UnitTestingDemo.Handlers;

namespace UnitTestingDemo.Website.Tests.layouts.UnitTestingDemo.Handlers
{
    [TestClass]
    public class RecipeDownloadHandlerTest : UnitTestingDemoTestBase
    {
        [TestMethod]
        public void GetRecipeML()
        {
            // Get the fixture item as set in the fixture TDS project
            Recipe recipe = ItemWrapper.CreateTypedWrapper(
                Sitecore.Context.Database.GetItem("/sitecore/content/UnitTestingDemo/Home/Recipe manager/9os Style Chicken Salad"))
                    as Recipe;
            Assert.IsNotNull(recipe);

            // Call the method that we're testing
            XDocument result = RecipeDownloadHandler.GetRecipeML(recipe);

            // Check if the content of the generated XML is correct
            Assert.IsNotNull(result);
            Assert.AreEqual("'9os Style Chicken Salad", result.Root.Element("recipe").Element("head").Element("title").Value);
            Assert.AreEqual(2, result.Root.Element("recipe").Element("head").Element("categories").Elements("cat").Count());
            Assert.AreEqual(11, result.Root.Element("recipe").Element("ingredients").Elements("ing").Count());

            // Check an individual ingredient
            XElement firstIngredient = result.Root.Element("recipe").Element("ingredients").Elements("ing").First();
            Assert.AreEqual("(11 oz's.) mandarin oranges, drained", firstIngredient.Element("item").Value);
            Assert.AreEqual("1", firstIngredient.Element("amt").Element("qty").Value);
            Assert.AreEqual("can", firstIngredient.Element("amt").Element("unit").Value);

            Assert.IsTrue(result.Root.Element("recipe").Element("directions").Element("step").Value
                .Contains("In deep saucepan, place chicken."));
        }

        [TestMethod]
        public void GetEmptyRecipeML()
        {
            // Get the recipe manager page, where we can create a new recipe as a child
            Item recipeManager = Sitecore.Context.Database.GetItem("/sitecore/content/UnitTestingDemo/Home/Recipe manager");
            Assert.IsNotNull(recipeManager);

            // Create an empty recipe (we could also have placed this in the fixtures and reference it directly)
            Recipe recipe = ItemWrapper.CreateTypedWrapper(
                recipeManager.Add("Empty recipe", new TemplateID(Recipe.TEMPLATE_ID))) as Recipe;
            Assert.IsNotNull(recipe);

            // Call the method that we're testing
            XDocument result = RecipeDownloadHandler.GetRecipeML(recipe);

            // Required behavior in this case is that the elements are defined, but empty in the XML, so we can check that
            Assert.AreEqual(string.Empty, result.Root.Element("recipe").Element("head").Element("title").Value);
            Assert.IsNotNull(result.Root.Element("recipe").Element("ingredients"));
            Assert.IsNotNull(result.Root.Element("recipe").Element("directions"));
        }

        [TestMethod]
        public void GetNullRecipeML()
        {
            // Call the method that we're testing
            XDocument result = RecipeDownloadHandler.GetRecipeML(null);

            // Required behavior in this case is that when null is passed, no XML document will be returned
            Assert.IsNull(result);
        }
    }
}
