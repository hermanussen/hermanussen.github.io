﻿using System;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Rhino.Mocks;
using Sitecore.Data;
using Sitecore.Data.Items;
using Sitecore.Diagnostics;
using UnitTestingDemo.Website.Controllers;
using UnitTestingDemo.Website.Domain;
using UnitTestingDemo.Website.Domain.DomainModel;
using UnitTestingDemo.Website.Tests.Util;
using Assert = Microsoft.VisualStudio.TestTools.UnitTesting.Assert;

namespace UnitTestingDemo.Website.Tests.Controllers
{
    [TestClass]
    public class RecipeManagerControllerTest : UnitTestingDemoTestBase
    {
        [TestMethod]
        [DeploymentItem("Testfiles/1-1-1_Cookies.xml", "Testfiles")]
        public void TestIndex()
        {
            FileInfo testFile = new FileInfo("Testfiles/1-1-1_Cookies.xml");
            Assert.IsTrue(testFile.Exists);

            // Run the upload logic on the RecipeManagerController
            RecipeManagerController controller = RunUpload(testFile);
            Console.WriteLine(string.Format("Status message: {0}", controller.ViewBag.UploadStatusMessage));
            Assert.IsTrue(controller.ViewBag.UploadStatusSuccess);

            // Get the imported recipe
            Recipe cookiesRecipe = ItemWrapper.CreateTypedWrapper(
                Sitecore.Context.Database.GetItem("/sitecore/content/UnitTestingDemo/Home/Recipe manager/111 Cookies")) as Recipe;
            Assert.IsNotNull(cookiesRecipe);

            // Check the data that was imported
            Assert.AreEqual("1-1-1 Cookies", cookiesRecipe.Title);
            Assert.IsTrue(cookiesRecipe.TextContent.Contains("Blend and drop onto cookie sheet."));
            Assert.AreEqual(1, cookiesRecipe.GetCategories<RecipeCategory>().Count());
            Assert.AreEqual("None", cookiesRecipe.GetCategories<RecipeCategory>().First().CategoryName);
            Assert.AreEqual(3, cookiesRecipe.GetChildren<IngredientUse>().Count());

            // Check the ingredients
            IngredientUse peanutButter = cookiesRecipe.GetChildren<IngredientUse>()
                .First(ing => "Peanut butter".Equals(ing.GetIngredient<Ingredient>().Name));
            Assert.IsNotNull(peanutButter);
            Assert.AreEqual("1", peanutButter.Quantity);
            Assert.AreEqual("cup", peanutButter.Unit);
        }

        [TestMethod]
        [DeploymentItem("Testfiles/1-1-1_Cookies_with_invalid_xml.xml", "Testfiles")]
        public void TestIndexWithInvalidXml()
        {
            FileInfo testFile = new FileInfo("Testfiles/1-1-1_Cookies_with_invalid_xml.xml");
            Assert.IsTrue(testFile.Exists);

            // Run the upload logic on the RecipeManagerController
            RecipeManagerController controller = RunUpload(testFile);
            Console.WriteLine(string.Format("Status message: {0}", controller.ViewBag.UploadStatusMessage));
            Assert.IsFalse(controller.ViewBag.UploadStatusSuccess);
        }

        [TestMethod]
        [DeploymentItem("Testfiles/recipes.zip", "Testfiles")]
        public void TestIndexWithZipFile()
        {
            FileInfo testFile = new FileInfo("Testfiles/recipes.zip");
            Assert.IsTrue(testFile.Exists);

            // Run the upload logic on the RecipeManagerController
            RecipeManagerController controller = RunUpload(testFile, "application/x-zip-compressed");
            Console.WriteLine(string.Format("Status message: {0}", controller.ViewBag.UploadStatusMessage));
            Assert.IsTrue(controller.ViewBag.UploadStatusSuccess);
        }

        /// <summary>
        /// Helper method that mocks the uploaded file and calls the controller method.
        /// </summary>
        /// <param name="testFile"></param>
        /// <param name="contentType"></param>
        /// <returns></returns>
        private static RecipeManagerController RunUpload(FileInfo testFile, string contentType = "application/xml")
        {
            // Mock the HttpPostedFileBase that is used by the controller
            HttpPostedFileBase mockPostedFile = MockRepository.GenerateStub<HttpPostedFileBase>();
            mockPostedFile.Stub(x => x.ContentType).Return(contentType);
            mockPostedFile.Stub(x => x.FileName).Return(testFile.Name);
            mockPostedFile.Stub(x => x.InputStream).Return(testFile.OpenRead());

            // Execute te controller method that we're testing
            using (new ContextItemSwitcher(
                Sitecore.Context.Database.GetItem("/sitecore/content/UnitTestingDemo/Home/Recipe manager")))
            {
                RecipeManagerController controller = new RecipeManagerController();
                ActionResult result = controller.Index(mockPostedFile);
                Assert.IsNotNull(result);
                return controller;
            }
        }
    }
}
