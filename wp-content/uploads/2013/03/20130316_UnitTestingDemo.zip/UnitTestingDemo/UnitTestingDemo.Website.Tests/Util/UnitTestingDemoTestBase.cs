﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FixtureDataProvider.Test;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Sitecore.Data.Items;
using Sitecore.Mvc.Presentation;
using UnitTestingDemo.Website.Domain;
using UnitTestingDemo.Website.Models;

namespace UnitTestingDemo.Website.Tests.Util
{
    [DeploymentItem("bin/Debug/sitecore.nexus.dll")]
    [DeploymentItem("bin/Debug/Sitecore.Analytics.dll")]
    [DeploymentItem("bin/Debug/System.Web.dll")]
    [DeploymentItem("bin/Debug/System.Web.Helpers.dll")]
    [DeploymentItem("bin/Debug/System.Web.WebPages.dll")]
    [DeploymentItem("bin/Debug/System.Web.WebPages.Deployment.dll")]
    [DeploymentItem("bin/Debug/System.Web.Mvc.dll")]
    [DeploymentItem("bin/Debug/UnitTestingDemo.Website")]
    public class UnitTestingDemoTestBase : SitecoreUnitTestBase
    {
        private const string TestProjectHome = @"C:\Demo\SitecoreDemo\UnitTestingDemo\UnitTestingDemo.Website\";

        /// <summary>
        /// Renders a view that has a RenderingModel<ItemWrapper> as a model.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="item"></param>
        /// <param name="viewPath"></param>
        /// <returns></returns>
        protected RazorViewExecutionResult RenderCdmBasedView<T>(Item item, string viewPath) where T : ItemWrapper
        {
            IRenderingModel<T> renderingModel = new RenderingModel<T>();
            renderingModel.Initialize(new Rendering() { Item = item });
            RazorViewExecutionResult result =
                RazorHelper<IRenderingModel<T>>.GenerateAndExecuteTemplate(
                    string.Format("{0}{1}", TestProjectHome, viewPath),
                    renderingModel);
            return result;
        }
    }
}
