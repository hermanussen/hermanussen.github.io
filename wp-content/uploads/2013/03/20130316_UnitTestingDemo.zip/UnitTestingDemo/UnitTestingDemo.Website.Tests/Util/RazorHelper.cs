﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Razor;
using System.Web.Razor;
using System.Web.Routing;
using System.Web.WebPages;
using Microsoft.CSharp;
using Rhino.Mocks;

namespace UnitTestingDemo.Website.Tests.Util
{
    public class RazorViewExecutionResult
    {
        public string Text { get; set; }
        public IList<string> SectionNames { get; private set; }

        public RazorViewExecutionResult()
        {
            SectionNames = new List<string>();
        }
    }

    /// <summary>
    /// Helper class based on http://httputility.com/article/unit-testing-razor-views.
    /// Enables unit testing of Razor views.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public static class RazorHelper<T>
    {

        public static RazorViewExecutionResult GenerateAndExecuteTemplate(string templateName, T model)
        {
            return GenerateAndExecuteTemplate(templateName, model, null, null);
        }

        public static RazorViewExecutionResult GenerateAndExecuteTemplate
            (string templateName, T model, HttpContextBase httpContext)
        {
            return GenerateAndExecuteTemplate(templateName, model, httpContext, null);
        }

        public static RazorViewExecutionResult GenerateAndExecuteTemplate
            (string templateName, T model, HttpContextBase httpContext, Action<WebViewPage<T>> modifyViewBag)
        {
            string view = File.ReadAllText(templateName);
            var template = RazorHelper<T>.GenerateTemplate(view);
            if (modifyViewBag != null)
                modifyViewBag(template);
            var result = RazorHelper<T>.ExecuteTemplate(template, model, httpContext);
            Console.WriteLine(result.Text);
            return result;
        }

        private static RazorTemplateEngine SetupRazorEngine()
        {
            // Set up the hosting environment (filename here is only used to trick RazorTemplateEngine)
            var host = new MvcWebPageRazorHost("~/test.cshtml", System.Environment.CurrentDirectory);

            host.NamespaceImports.Add("System.Web.Mvc.Html");
            // TODO: add your namespaces here
            host.NamespaceImports.Add("System.Web.Mvc");
            host.NamespaceImports.Add("System.Web.Mvc.Ajax");
            host.NamespaceImports.Add("System.Web.Mvc.Html");
            host.NamespaceImports.Add("System.Web.Routing");
            host.NamespaceImports.Add("Sitecore.Mvc");
            host.NamespaceImports.Add("UnitTestingDemo.Website.Util");

            // Create the template engine using this host
            return new RazorTemplateEngine(host);
        }

        public static RazorViewExecutionResult ExecuteTemplate(WebViewPage<T> viewPage, T model)
        {
            return ExecuteTemplate(viewPage, model, null);
        }

        public static RazorViewExecutionResult ExecuteTemplate(WebViewPage<T> viewPage, T model, HttpContextBase httpContext)
        {
            var result = new RazorViewExecutionResult();

            // Warning: lots of mocking below

            // mock HTTP state objects
            var context = MockRepository.GenerateMock<HttpContextBase>();
            context.Expect(x => x.Items).Return(new Dictionary<object, object>());
            var response = MockRepository.GenerateMock<HttpResponseBase>();
            response.Expect(x => x.ApplyAppPathModifier("")).IgnoreArguments().Repeat.Any()
                .Return("")
                .WhenCalled(x => { x.ReturnValue = x.Arguments[0]; });
            context.Expect(x => x.Response).Repeat.Any().Return(response);
            var request = MockRepository.GenerateMock<HttpRequestBase>();
            context.Expect(x => x.Request).Repeat.Any().Return(request);
            request.Expect(x => x.ApplicationPath).Repeat.Any().Return("/");
            request.Expect(x => x.IsLocal).Repeat.Any().Return(true);
            var requestRouteContext = new RequestContext(context, new RouteData());
            // mock page view context
            var view = MockRepository.GenerateMock<ViewContext>();
            var mock = new MockRepository();
            view.Expect(x => x.HttpContext).Repeat.Any().Return(context);
            var viewMock = MockRepository.GenerateMock<IView>();
            view.Expect(x => x.View).Repeat.Any().Return(viewMock);
            view.Expect(x => x.TempData).Repeat.Any().Return(new TempDataDictionary());
            view.Expect(x => x.ViewData).Repeat.Any().Return(new ViewDataDictionary<T>(model));
            var viewDataContainer = MockRepository.GenerateMock<IViewDataContainer>();
            // mock view data used by the page
            viewDataContainer.Expect(c => c.ViewData).Repeat.Any().Return(new ViewDataDictionary<T>(model));
            // mock html helper
            var html = mock.DynamicMock<HtmlHelper<T>>(view, viewDataContainer);
            var urlHelper = MockRepository.GenerateMock<UrlHelper>(requestRouteContext);
            // mock viewengine (for partial views fake resolution)
            var viewEngine = MockRepository.GenerateMock<IViewEngine>();
            viewEngine.Expect(x => x.FindPartialView(null, null, false)).IgnoreArguments()
                .Repeat.Any().Return(new ViewEngineResult(viewMock, viewEngine));

            using (var tw = new StringWriter())
            using (var twNull = new StringWriter()) // this writer is used to discard unnecessary results
            {
                view.Expect(x => x.Writer).Repeat.Any().Return(tw);

                // inject mocked context
                viewPage.Context = httpContext;

                var pageContext = new WebPageContext(context: context, page: null, model: null);
                viewPage.ViewContext = view;
                if (model != null)
                    viewPage.ViewData = new ViewDataDictionary<T>(model);
                viewPage.Html = html;
                viewPage.Url = urlHelper;

                // insert mocked viewEngine for fake partial views resolution
                ViewEngines.Engines.Clear();
                ViewEngines.Engines.Add(viewEngine);

                // prepare view for execution, discard all generated results
                viewPage.PushContext(pageContext, twNull);
                viewPage.ExecutePageHierarchy(pageContext, twNull);
                // inject textwriter
                viewPage.OutputStack.Push(tw);
                // execute compiled page
                viewPage.Execute();

                // find all sections and render them too
                PropertyInfo dynMethod = pageContext.GetType().GetProperty("SectionWritersStack", BindingFlags.NonPublic | BindingFlags.Instance);
                var res = (Stack<Dictionary<string, SectionWriter>>)dynMethod.GetValue(pageContext, null);
                foreach (var section in res.Peek())
                {
                    section.Value();
                    result.SectionNames.Add(section.Key);
                }

                result.Text = tw.ToString();
                return result;
            }
        }

        public static WebViewPage<T> GenerateTemplate(string input)
        {
            WebViewPage<T> result = null;
            var _engine = SetupRazorEngine();

            // Generate code for the template
            GeneratorResults razorResult = null;
            Regex layout = new Regex("Layout = .*");
            input = layout.Replace(input, string.Empty); // layouts cannot be rendered in unit test environment
            using (TextReader rdr = new StringReader(input))
            {
                razorResult = _engine.GenerateCode(rdr);
            }

            var codeProvider = new CSharpCodeProvider();

            // generate C# code
            using (var sw = new StringWriter())
            {
                codeProvider.GenerateCodeFromCompileUnit(razorResult.GeneratedCode, sw, new CodeGeneratorOptions());
            }

            var compParams = new CompilerParameters(new string[] {
				typeof(RazorHelper<>).Assembly.CodeBase.Replace("file:///", "").Replace("/", "\\")
			});
            compParams.GenerateInMemory = true;
            compParams.ReferencedAssemblies.Add("System.dll");
            compParams.ReferencedAssemblies.Add("System.Core.dll");
            compParams.ReferencedAssemblies.Add("System.Net.dll");
            compParams.ReferencedAssemblies.Add("System.Web.dll");
            compParams.ReferencedAssemblies.Add("System.Web.Mvc.dll");
            compParams.ReferencedAssemblies.Add("Microsoft.CSharp.dll");

            compParams.ReferencedAssemblies.Add("Sitecore.Mvc.dll");
            compParams.ReferencedAssemblies.Add("Sitecore.Kernel.dll");
            compParams.ReferencedAssemblies.Add("Sitecore.Nexus.dll");
            compParams.ReferencedAssemblies.Add("System.Web.Helpers.dll");
            compParams.ReferencedAssemblies.Add("System.Web.WebPages.dll");
            compParams.ReferencedAssemblies.Add("System.Web.WebPages.Deployment.dll");
            compParams.ReferencedAssemblies.Add("CompiledDomainModel.dll");

            compParams.ReferencedAssemblies.Add("UnitTestingDemo.Website.dll");

            //compParams.ReferencedAssemblies.Add("");

            // TODO: add your assemblies here
            compParams.IncludeDebugInformation = true;

            // Compile the generated code into an assembly
            CompilerResults results = codeProvider.CompileAssemblyFromDom(
                compParams,
                razorResult.GeneratedCode);

            if (results.Errors.HasErrors)
            {
                CompilerError err = results.Errors
                                           .OfType<CompilerError>()
                                           .Where(ce => !ce.IsWarning)
                                           .First();
                throw new HttpCompileException(String.Format("Error Compiling Template: ({0}, {1}) {2}",
                                              err.Line, err.Column, err.ErrorText));
            }
            else
            {
                // Load the assembly
                Assembly asm = results.CompiledAssembly;
                if (asm == null)
                {
                    throw new HttpCompileException("Error loading template assembly");
                }
                else
                {
                    // Get the template type
                    Type typ = asm.GetType("ASP._Page_test_cshtml"); // remember the fake filename?
                    if (typ == null)
                    {
                        throw new HttpCompileException(string.Format("Could not find type ASP._Page_test_cshtml in assembly {0}", asm.FullName));
                    }
                    else
                    {
                        result = Activator.CreateInstance(typ) as WebViewPage<T>;
                        if (result == null)
                        {
                            throw new HttpCompileException("Could not construct RazorOutput.Template or it does not inherit from ASP._Page_test_cshtml");
                        }
                    }
                }
            }

            return result;
        }
    }


}
