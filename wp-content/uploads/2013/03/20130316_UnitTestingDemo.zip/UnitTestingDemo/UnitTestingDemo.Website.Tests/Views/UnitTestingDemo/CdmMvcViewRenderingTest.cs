﻿using System;
using System.Web;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FixtureDataProvider.Test;
using Sitecore.Collections;
using Sitecore.Data.Fields;
using Sitecore.Data.Items;
using Sitecore.Mvc.Helpers;
using Sitecore.Mvc.Presentation;
using Sitecore.Pipelines;
using Sitecore.Pipelines.RenderField;
using Sitecore.Xml.Xsl;
using UnitTestingDemo.Website.Domain;
using UnitTestingDemo.Website.Domain.DomainModel;
using UnitTestingDemo.Website.Tests.Util;

namespace UnitTestingDemo.Website.Tests.Views.UnitTestingDemo
{
    [TestClass]
    public class CdmMvcViewRenderingTest : UnitTestingDemoTestBase
    {
        [TestMethod]
        public void TestView()
        {
            Item item = Sitecore.Context.Database.GetItem("/sitecore/content/UnitTestingDemo/Home/Cdm mvc view rendering");
            Assert.IsNotNull(item);

            RazorViewExecutionResult result = RenderCdmBasedView<Page>(item, @"Views\UnitTestingDemo\CdmMvcViewRendering.cshtml");
            Assert.IsFalse(string.IsNullOrWhiteSpace(result.Text));
            Assert.IsTrue(result.Text.Contains("Cdm mvc view rendering"));
            Assert.IsTrue(result.Text.Contains("This page was rendered using MVC"));
        }

    }
}
